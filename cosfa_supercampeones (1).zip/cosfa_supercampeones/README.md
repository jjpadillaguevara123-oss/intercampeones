# 🏆 Cosfa Supercampeones
Sistema Web de Torneos Interclases con Temática del Mundial

## ⚡ Instalación Rápida

```bash
# 1. Instalar dependencias
pip install -r requirements.txt

# 2. Crear migraciones
python manage.py makemigrations
python manage.py migrate

# 3. Cargar datos iniciales (países, ciclos, grados)
python manage.py cargar_datos_iniciales

# 4. Crear superusuario Django (opcional)
python manage.py createsuperuser

# 5. Iniciar servidor
python manage.py runserver
```

## 🌐 URLs del sistema

| URL | Descripción |
|-----|-------------|
| `http://localhost:8000/` | Sitio público |
| `http://localhost:8000/admin-cosfa/login/` | Login administrador |
| `http://localhost:8000/admin-cosfa/` | Panel de administración |
| `http://localhost:8000/django-admin/` | Admin técnico Django |

## 🔐 Contraseña del Admin
La contraseña está en `cosfa_supercampeones/settings.py`:
```python
ADMIN_PASSWORD = 'cosfa2025'
```
Cámbiala antes de poner el sistema en producción.

## 📋 Flujo de Uso

### Como Administrador:
1. Ir a `/admin-cosfa/login/` e ingresar contraseña
2. Crear **Año Lectivo** activo (ej: 2025-2026)
3. Verificar que los **Grados** y **Países** estén cargados
4. Crear **Torneos** (deporte + ciclo + género)
5. Para cada torneo: ir a **Sorteo**
   - Seleccionar grados participantes
   - Seleccionar países disponibles
   - Click en **REALIZAR SORTEO ALEATORIO**
   - Generar **Grupos**
   - Generar **Fixture**
6. Ir a **Partidos** → **Registrar** cada partido
7. Para Ciclos III y IV: activar **votación MVP**

### Como Usuario Normal:
- Ver partidos, resultados, tablas de posiciones
- Ver estadísticas (goleadores, tarjetas, valla invicta)
- Ver calendario por torneo
- Votar MVP (solo capitanes, con su ID)

## 🗂 Estructura del Proyecto

```
cosfa_supercampeones/
├── cosfa_supercampeones/    # Configuración Django
│   ├── settings.py
│   └── urls.py
├── torneos/                 # App principal
│   ├── models.py            # Modelos de BD
│   ├── views.py             # Vistas públicas
│   ├── views_admin.py       # Vistas del admin
│   ├── services.py          # Lógica: sorteo, fixture, estadísticas
│   ├── forms.py             # Formularios
│   ├── decorators.py        # Autenticación admin
│   └── management/
│       └── commands/
│           └── cargar_datos_iniciales.py
├── templates/
│   ├── base.html            # Base pública
│   ├── torneos/             # Templates públicos
│   └── admin_cosfa/         # Templates del panel admin
├── static/                  # CSS, JS, imágenes
├── media/                   # Archivos subidos
├── manage.py
└── requirements.txt
```

## 🏗 Modelos de Base de Datos

- **AnoLectivo** — Año escolar activo
- **Ciclo** — I, II, III, IV
- **Grado** — 1°, 2°, ..., 11°, Profesores
- **Pais** — 32 países del mundo con colores
- **Jugador** — Estudiante con ID, grado, género
- **Torneo** — Deporte + Ciclo + Género + Formato
- **Equipo** — País asignado aleatoriamente a un grado
- **JugadorEquipo** — Jugadores inscritos por torneo
- **Grupo** — Grupos A, B, C... generados aleatoriamente
- **EquipoGrupo** — Estadísticas por grupo (puntos, goles, etc.)
- **Partido** — Con fecha, estado, marcador
- **Gol** — Jugador, minuto, tipo (normal/autogol/penalti)
- **Tarjeta** — Amarilla, Roja, Doble Amarilla
- **Alineacion** — Titular/Suplente por partido
- **CandidatoMVP** — Candidatos al MVP por torneo
- **VotoMVP** — Un voto por capitán por torneo

## ⚙️ Tecnologías
- **Backend:** Django 4.2 (Python)
- **Base de datos:** SQLite (desarrollo) / PostgreSQL (producción)
- **Frontend:** HTML5, CSS3 (custom), JavaScript vanilla
- **Fonts:** Bebas Neue, Rajdhani, Inter (Google Fonts)
- **Iconos:** Font Awesome 6.5
