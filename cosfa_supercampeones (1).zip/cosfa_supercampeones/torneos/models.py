from django.db import models
import random


# ─────────────────────────────────────────
# AÑO LECTIVO
# ─────────────────────────────────────────

class AnoLectivo(models.Model):
    nombre = models.CharField(max_length=20, unique=True)
    activo = models.BooleanField(default=True)
    fecha_inicio = models.DateField()
    fecha_fin = models.DateField(null=True, blank=True)

    class Meta:
        verbose_name = "Año Lectivo"
        verbose_name_plural = "Años Lectivos"
        ordering = ['-nombre']

    def __str__(self):
        return self.nombre

    def save(self, *args, **kwargs):
        if self.activo:
            AnoLectivo.objects.exclude(pk=self.pk).update(activo=False)
        super().save(*args, **kwargs)


# ─────────────────────────────────────────
# PAÍSES
# ─────────────────────────────────────────

class Pais(models.Model):
    nombre = models.CharField(max_length=100, unique=True)
    codigo = models.CharField(max_length=3, unique=True)
    bandera = models.ImageField(upload_to='banderas/', null=True, blank=True)
    color_principal = models.CharField(max_length=7, default='#000000')
    color_secundario = models.CharField(max_length=7, default='#FFFFFF')

    class Meta:
        verbose_name = "País"
        verbose_name_plural = "Países"
        ordering = ['nombre']

    def __str__(self):
        return f"{self.nombre} ({self.codigo})"


# ─────────────────────────────────────────
# CICLOS Y GRADOS
# ─────────────────────────────────────────

class Ciclo(models.Model):
    CICLOS = [
        ('I', 'Ciclo I (1° y 2°)'),
        ('II', 'Ciclo II (3°, 4°, 5°)'),
        ('III', 'Ciclo III (6°, 7°, 8°)'),
        ('IV', 'Ciclo IV (9°, 10°, 11° y Profesores)'),
    ]
    nombre = models.CharField(max_length=5, choices=CICLOS, unique=True)
    descripcion = models.CharField(max_length=100, blank=True)

    class Meta:
        ordering = ['nombre']

    def __str__(self):
        return self.get_nombre_display()


class Grado(models.Model):
    nombre = models.CharField(max_length=50)
    ciclo = models.ForeignKey(Ciclo, on_delete=models.CASCADE, related_name='grados')
    orden = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['ciclo', 'orden', 'nombre']
        unique_together = ['nombre', 'ciclo']

    def __str__(self):
        return f"{self.nombre}"


# ─────────────────────────────────────────
# JUGADORES
# ─────────────────────────────────────────

class Jugador(models.Model):
    TIPO_DOC = [
        ('TI', 'Tarjeta de Identidad'),
        ('CC', 'Cédula de Ciudadanía'),
    ]
    GENERO = [
        ('M', 'Masculino'),
        ('F', 'Femenino'),
    ]
    identificacion = models.CharField(max_length=20, unique=True)
    tipo_doc = models.CharField(max_length=2, choices=TIPO_DOC, default='TI')
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    genero = models.CharField(max_length=1, choices=GENERO)
    grado = models.ForeignKey(Grado, on_delete=models.SET_NULL, null=True, related_name='jugadores')
    foto = models.ImageField(upload_to='jugadores/', null=True, blank=True)
    activo = models.BooleanField(default=True)
    fecha_registro = models.DateField(auto_now_add=True)

    class Meta:
        ordering = ['apellido', 'nombre']

    def __str__(self):
        return f"{self.nombre} {self.apellido}"

    @property
    def nombre_completo(self):
        return f"{self.nombre} {self.apellido}"

    def total_goles(self):
        return self.goles.filter(es_autogol=False).count()

    def total_tarjetas_amarillas(self):
        return self.tarjetas.filter(tipo='amarilla').count()

    def total_tarjetas_rojas(self):
        return self.tarjetas.filter(tipo__in=['roja', 'doble_amarilla']).count()


# ─────────────────────────────────────────
# TORNEOS
# ─────────────────────────────────────────

class Torneo(models.Model):
    DEPORTES = [
        ('futbol', 'Fútbol ⚽'),
        ('baloncesto', 'Baloncesto 🏀'),
        ('voleibol', 'Voleibol 🏐'),
    ]
    GENERO = [
        ('M', 'Masculino'),
        ('F', 'Femenino'),
    ]
    FORMATO = [
        ('grupos', 'Fase de Grupos'),
        ('todos', 'Todos contra Todos'),
    ]
    ESTADO = [
        ('pendiente', 'Pendiente'),
        ('sorteo', 'En Sorteo'),
        ('en_curso', 'En Curso'),
        ('finalizado', 'Finalizado'),
    ]

    ano_lectivo = models.ForeignKey(AnoLectivo, on_delete=models.CASCADE, related_name='torneos')
    deporte = models.CharField(max_length=20, choices=DEPORTES)
    ciclo = models.ForeignKey(Ciclo, on_delete=models.CASCADE)
    genero = models.CharField(max_length=1, choices=GENERO)
    formato = models.CharField(max_length=10, choices=FORMATO, default='grupos')
    estado = models.CharField(max_length=15, choices=ESTADO, default='pendiente')
    fecha_inicio = models.DateField(null=True, blank=True)
    mvp_activo = models.BooleanField(default=False)
    descripcion = models.TextField(blank=True)

    class Meta:
        unique_together = ['ano_lectivo', 'deporte', 'ciclo', 'genero']
        verbose_name = "Torneo"
        ordering = ['deporte', 'ciclo', 'genero']

    def __str__(self):
        return f"{self.get_deporte_display()} | {self.ciclo} | {self.get_genero_display()} | {self.ano_lectivo}"

    def puede_tener_mvp(self):
        return self.ciclo.nombre in ['III', 'IV']

    def total_partidos(self):
        return self.partidos.count()

    def partidos_jugados(self):
        return self.partidos.filter(estado='finalizado').count()

    def partidos_pendientes(self):
        return self.partidos.filter(estado='programado').count()

    def icono_deporte(self):
        iconos = {'futbol': '⚽', 'baloncesto': '🏀', 'voleibol': '🏐'}
        return iconos.get(self.deporte, '🏆')


# ─────────────────────────────────────────
# EQUIPOS
# ─────────────────────────────────────────

class Equipo(models.Model):
    torneo = models.ForeignKey(Torneo, on_delete=models.CASCADE, related_name='equipos')
    pais = models.ForeignKey(Pais, on_delete=models.CASCADE)
    grado = models.ForeignKey(Grado, on_delete=models.CASCADE)
    logo = models.ImageField(upload_to='logos_equipos/', null=True, blank=True)
    capitan = models.ForeignKey(
        'Jugador', on_delete=models.SET_NULL,
        null=True, blank=True, related_name='capitan_de'
    )

    class Meta:
        unique_together = ['torneo', 'grado']

    def __str__(self):
        return f"{self.pais.nombre} ({self.grado})"

    def partidos_ganados(self):
        ganados = 0
        for p in self.partidos_local.filter(estado='finalizado'):
            if p.goles_local > p.goles_visitante:
                ganados += 1
        for p in self.partidos_visitante.filter(estado='finalizado'):
            if p.goles_visitante > p.goles_local:
                ganados += 1
        return ganados


class JugadorEquipo(models.Model):
    jugador = models.ForeignKey(Jugador, on_delete=models.CASCADE, related_name='equipos_historico')
    equipo = models.ForeignKey(Equipo, on_delete=models.CASCADE, related_name='jugadores')
    es_capitan = models.BooleanField(default=False)
    numero_camiseta = models.PositiveIntegerField(null=True, blank=True)
    fecha_inscripcion = models.DateField(auto_now_add=True)

    class Meta:
        unique_together = ['jugador', 'equipo']

    def __str__(self):
        return f"{self.jugador} → {self.equipo}"


# ─────────────────────────────────────────
# GRUPOS
# ─────────────────────────────────────────

class Grupo(models.Model):
    torneo = models.ForeignKey(Torneo, on_delete=models.CASCADE, related_name='grupos')
    nombre = models.CharField(max_length=10)

    class Meta:
        ordering = ['nombre']

    def __str__(self):
        return f"Grupo {self.nombre} - {self.torneo}"


class EquipoGrupo(models.Model):
    grupo = models.ForeignKey(Grupo, on_delete=models.CASCADE, related_name='equipos')
    equipo = models.ForeignKey(Equipo, on_delete=models.CASCADE, related_name='grupos')

    puntos = models.IntegerField(default=0)
    partidos_jugados = models.IntegerField(default=0)
    partidos_ganados = models.IntegerField(default=0)
    partidos_empatados = models.IntegerField(default=0)
    partidos_perdidos = models.IntegerField(default=0)
    goles_favor = models.IntegerField(default=0)
    goles_contra = models.IntegerField(default=0)
    valla_invicta = models.BooleanField(default=True)

    @property
    def diferencia_goles(self):
        return self.goles_favor - self.goles_contra

    class Meta:
        ordering = ['-puntos', '-goles_favor', 'goles_contra']
        unique_together = ['grupo', 'equipo']

    def __str__(self):
        return f"{self.equipo} - {self.grupo}"


# ─────────────────────────────────────────
# PARTIDOS
# ─────────────────────────────────────────

class Partido(models.Model):
    ESTADO = [
        ('programado', 'Programado'),
        ('en_juego', 'En Juego'),
        ('finalizado', 'Finalizado'),
        ('suspendido', 'Suspendido'),
    ]
    FASE = [
        ('grupos', 'Fase de Grupos'),
        ('cuartos', 'Cuartos de Final'),
        ('semifinal', 'Semifinal'),
        ('tercer_puesto', 'Tercer Puesto'),
        ('final', 'Final'),
    ]

    torneo = models.ForeignKey(Torneo, on_delete=models.CASCADE, related_name='partidos')
    grupo = models.ForeignKey(Grupo, on_delete=models.SET_NULL, null=True, blank=True)
    equipo_local = models.ForeignKey(Equipo, on_delete=models.CASCADE, related_name='partidos_local')
    equipo_visitante = models.ForeignKey(Equipo, on_delete=models.CASCADE, related_name='partidos_visitante')
    fecha = models.DateTimeField(null=True, blank=True)
    numero_partido = models.PositiveIntegerField()
    fase = models.CharField(max_length=20, choices=FASE, default='grupos')
    estado = models.CharField(max_length=15, choices=ESTADO, default='programado')
    goles_local = models.IntegerField(default=0)
    goles_visitante = models.IntegerField(default=0)
    lugar = models.CharField(max_length=100, blank=True)
    observaciones = models.TextField(blank=True)

    class Meta:
        ordering = ['numero_partido']

    def __str__(self):
        return f"Partido {self.numero_partido}: {self.equipo_local} vs {self.equipo_visitante}"

    def resultado(self):
        return f"{self.goles_local} - {self.goles_visitante}"

    def ganador(self):
        if self.goles_local > self.goles_visitante:
            return self.equipo_local
        elif self.goles_visitante > self.goles_local:
            return self.equipo_visitante
        return None


class Gol(models.Model):
    partido = models.ForeignKey(Partido, on_delete=models.CASCADE, related_name='goles')
    jugador = models.ForeignKey(Jugador, on_delete=models.CASCADE, related_name='goles')
    equipo = models.ForeignKey(Equipo, on_delete=models.CASCADE)
    minuto = models.PositiveIntegerField(null=True, blank=True)
    es_autogol = models.BooleanField(default=False)
    es_penalti = models.BooleanField(default=False)

    def __str__(self):
        tipo = " (AG)" if self.es_autogol else " (P)" if self.es_penalti else ""
        return f"Gol de {self.jugador}{tipo} - P{self.partido.numero_partido}"


class Tarjeta(models.Model):
    TIPO = [
        ('amarilla', 'Amarilla'),
        ('roja', 'Roja'),
        ('doble_amarilla', 'Doble Amarilla → Roja'),
    ]
    partido = models.ForeignKey(Partido, on_delete=models.CASCADE, related_name='tarjetas')
    jugador = models.ForeignKey(Jugador, on_delete=models.CASCADE, related_name='tarjetas')
    equipo = models.ForeignKey(Equipo, on_delete=models.CASCADE)
    tipo = models.CharField(max_length=20, choices=TIPO)
    minuto = models.PositiveIntegerField(null=True, blank=True)

    def __str__(self):
        return f"Tarjeta {self.tipo} → {self.jugador} - P{self.partido.numero_partido}"


class Alineacion(models.Model):
    partido = models.ForeignKey(Partido, on_delete=models.CASCADE, related_name='alineaciones')
    jugador = models.ForeignKey(Jugador, on_delete=models.CASCADE)
    equipo = models.ForeignKey(Equipo, on_delete=models.CASCADE)
    es_titular = models.BooleanField(default=True)
    posicion = models.CharField(max_length=50, blank=True)

    class Meta:
        unique_together = ['partido', 'jugador']

    def __str__(self):
        rol = "Titular" if self.es_titular else "Suplente"
        return f"{self.jugador} ({rol}) - P{self.partido.numero_partido}"


# ─────────────────────────────────────────
# MVP
# ─────────────────────────────────────────

class CandidatoMVP(models.Model):
    torneo = models.ForeignKey(Torneo, on_delete=models.CASCADE, related_name='candidatos_mvp')
    jugador = models.ForeignKey(Jugador, on_delete=models.CASCADE)
    grado = models.ForeignKey(Grado, on_delete=models.CASCADE)

    class Meta:
        unique_together = ['torneo', 'jugador']

    def total_votos(self):
        return self.votos_recibidos.count()

    def __str__(self):
        return f"Candidato: {self.jugador} - {self.torneo}"


class VotoMVP(models.Model):
    torneo = models.ForeignKey(Torneo, on_delete=models.CASCADE)
    capitan_votante = models.ForeignKey(Jugador, on_delete=models.CASCADE, related_name='votos_emitidos')
    candidato = models.ForeignKey(CandidatoMVP, on_delete=models.CASCADE, related_name='votos_recibidos')
    fecha_voto = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['torneo', 'capitan_votante']

    def __str__(self):
        return f"{self.capitan_votante} votó por {self.candidato.jugador}"
