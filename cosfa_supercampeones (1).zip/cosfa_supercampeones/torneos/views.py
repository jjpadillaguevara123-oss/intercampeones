from django.shortcuts import render, get_object_or_404, redirect
from django.db.models import Count, Sum, Q
from django.contrib import messages
from .models import (
    AnoLectivo, Torneo, Equipo, Partido, EquipoGrupo,
    Grupo, CandidatoMVP, VotoMVP, Jugador, Gol
)
from .forms import VotarMVPForm
from .services import EstadisticasService


def inicio(request):
    ano_activo = AnoLectivo.objects.filter(activo=True).first()
    torneos = []
    if ano_activo:
        torneos = Torneo.objects.filter(ano_lectivo=ano_activo).select_related('ciclo')

    context = {
        'ano_activo': ano_activo,
        'torneos': torneos,
        'anos': AnoLectivo.objects.all(),
    }
    return render(request, 'torneos/inicio.html', context)


def detalle_torneo(request, torneo_id):
    torneo = get_object_or_404(Torneo, id=torneo_id)
    grupos = torneo.grupos.prefetch_related('equipos__equipo__pais', 'equipos__equipo__grado').all()
    partidos_recientes = torneo.partidos.filter(estado='finalizado').order_by('-numero_partido')[:5]
    proximos = torneo.partidos.filter(estado='programado').order_by('numero_partido')[:5]

    context = {
        'torneo': torneo,
        'grupos': grupos,
        'partidos_recientes': partidos_recientes,
        'proximos': proximos,
    }
    return render(request, 'torneos/detalle_torneo.html', context)


def tabla_posiciones(request, torneo_id):
    torneo = get_object_or_404(Torneo, id=torneo_id)
    grupos = torneo.grupos.prefetch_related(
        'equipos__equipo__pais',
        'equipos__equipo__grado'
    ).all()

    context = {
        'torneo': torneo,
        'grupos': grupos,
    }
    return render(request, 'torneos/tabla_posiciones.html', context)


def calendario(request, torneo_id):
    torneo = get_object_or_404(Torneo, id=torneo_id)
    partidos = torneo.partidos.select_related(
        'equipo_local__pais', 'equipo_local__grado',
        'equipo_visitante__pais', 'equipo_visitante__grado',
        'grupo'
    ).all()

    partidos_jugados = partidos.filter(estado='finalizado')
    partidos_pendientes = partidos.filter(estado='programado')

    context = {
        'torneo': torneo,
        'partidos_jugados': partidos_jugados,
        'partidos_pendientes': partidos_pendientes,
        'todos_partidos': partidos,
    }
    return render(request, 'torneos/calendario.html', context)


def estadisticas(request, torneo_id):
    torneo = get_object_or_404(Torneo, id=torneo_id)
    goleadores = EstadisticasService.top_goleadores(torneo, limite=10)
    vallas = EstadisticasService.equipos_valla_invicta(torneo)

    # Tarjetas por jugador
    from django.db.models import Count
    tarjetas_amarillas = (
        Jugador.objects.filter(tarjetas__partido__torneo=torneo, tarjetas__tipo='amarilla')
        .annotate(total=Count('tarjetas'))
        .order_by('-total')[:10]
    )
    tarjetas_rojas = (
        Jugador.objects.filter(tarjetas__partido__torneo=torneo, tarjetas__tipo__in=['roja', 'doble_amarilla'])
        .annotate(total=Count('tarjetas'))
        .order_by('-total')[:10]
    )

    context = {
        'torneo': torneo,
        'goleadores': goleadores,
        'vallas': vallas,
        'tarjetas_amarillas': tarjetas_amarillas,
        'tarjetas_rojas': tarjetas_rojas,
    }
    return render(request, 'torneos/estadisticas.html', context)


def detalle_partido(request, partido_id):
    partido = get_object_or_404(Partido, id=partido_id)
    goles = partido.goles.select_related('jugador', 'equipo__pais').all()
    tarjetas = partido.tarjetas.select_related('jugador', 'equipo__pais').all()
    alineaciones_local = partido.alineaciones.filter(equipo=partido.equipo_local).select_related('jugador')
    alineaciones_visitante = partido.alineaciones.filter(equipo=partido.equipo_visitante).select_related('jugador')

    context = {
        'partido': partido,
        'goles': goles,
        'tarjetas': tarjetas,
        'alineaciones_local': alineaciones_local,
        'alineaciones_visitante': alineaciones_visitante,
    }
    return render(request, 'torneos/detalle_partido.html', context)


def mvp_view(request, torneo_id):
    torneo = get_object_or_404(Torneo, id=torneo_id)

    if not torneo.puede_tener_mvp():
        messages.error(request, "El MVP solo está disponible para Ciclos III y IV.")
        return redirect('detalle_torneo', torneo_id=torneo_id)

    candidatos = torneo.candidatos_mvp.select_related('jugador', 'grado').all()
    total_votos = VotoMVP.objects.filter(torneo=torneo).count()

    context = {
        'torneo': torneo,
        'candidatos': candidatos,
        'total_votos': total_votos,
        'mvp_activo': torneo.mvp_activo,
    }
    return render(request, 'torneos/mvp.html', context)


def votar_mvp(request, torneo_id, candidato_id):
    torneo = get_object_or_404(Torneo, id=torneo_id)

    if not torneo.mvp_activo:
        messages.error(request, "La votación MVP no está activa.")
        return redirect('mvp', torneo_id=torneo_id)

    if request.method == 'POST':
        identificacion = request.POST.get('identificacion', '').strip()

        try:
            jugador = Jugador.objects.get(identificacion=identificacion)
        except Jugador.DoesNotExist:
            messages.error(request, "Identificación no encontrada.")
            return redirect('mvp', torneo_id=torneo_id)

        # Verificar que es capitán
        es_capitan = jugador.capitan_de.filter(torneo=torneo).exists()
        if not es_capitan:
            messages.error(request, "Solo los capitanes pueden votar.")
            return redirect('mvp', torneo_id=torneo_id)

        # Verificar que no ha votado
        if VotoMVP.objects.filter(torneo=torneo, capitan_votante=jugador).exists():
            messages.warning(request, "Ya has emitido tu voto.")
            return redirect('mvp', torneo_id=torneo_id)

        candidato = get_object_or_404(CandidatoMVP, id=candidato_id, torneo=torneo)
        VotoMVP.objects.create(
            torneo=torneo,
            capitan_votante=jugador,
            candidato=candidato
        )
        messages.success(request, f"¡Voto registrado para {candidato.jugador.nombre_completo}!")

    return redirect('mvp', torneo_id=torneo_id)
