from django import forms
from .models import (
    AnoLectivo, Torneo, Equipo, Jugador, Grado, Ciclo,
    Partido, Gol, Tarjeta, Alineacion, CandidatoMVP,
    Pais, JugadorEquipo
)


class AnoLectivoForm(forms.ModelForm):
    class Meta:
        model = AnoLectivo
        fields = ['nombre', 'activo', 'fecha_inicio', 'fecha_fin']
        widgets = {
            'fecha_inicio': forms.DateInput(attrs={'type': 'date'}),
            'fecha_fin': forms.DateInput(attrs={'type': 'date'}),
        }


class TorneoForm(forms.ModelForm):
    class Meta:
        model = Torneo
        fields = ['ano_lectivo', 'deporte', 'ciclo', 'genero', 'formato', 'descripcion']
        widgets = {
            'descripcion': forms.Textarea(attrs={'rows': 2}),
        }


class GradoForm(forms.ModelForm):
    class Meta:
        model = Grado
        fields = ['nombre', 'ciclo', 'orden']


class JugadorForm(forms.ModelForm):
    class Meta:
        model = Jugador
        fields = ['identificacion', 'tipo_doc', 'nombre', 'apellido', 'genero', 'grado', 'foto', 'activo']
        widgets = {
            'foto': forms.FileInput(),
        }


class PaisForm(forms.ModelForm):
    class Meta:
        model = Pais
        fields = ['nombre', 'codigo', 'bandera', 'color_principal', 'color_secundario']
        widgets = {
            'color_principal': forms.TextInput(attrs={'type': 'color'}),
            'color_secundario': forms.TextInput(attrs={'type': 'color'}),
        }


class EquipoForm(forms.ModelForm):
    class Meta:
        model = Equipo
        fields = ['pais', 'grado', 'logo', 'capitan']
        widgets = {
            'logo': forms.FileInput(),
        }


class PartidoFechaForm(forms.ModelForm):
    class Meta:
        model = Partido
        fields = ['fecha', 'lugar']
        widgets = {
            'fecha': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        }


class RegistrarResultadoForm(forms.ModelForm):
    class Meta:
        model = Partido
        fields = ['goles_local', 'goles_visitante', 'estado', 'lugar', 'observaciones']
        widgets = {
            'goles_local': forms.NumberInput(attrs={'min': 0, 'max': 99}),
            'goles_visitante': forms.NumberInput(attrs={'min': 0, 'max': 99}),
            'observaciones': forms.Textarea(attrs={'rows': 2}),
        }


class GolForm(forms.ModelForm):
    class Meta:
        model = Gol
        fields = ['jugador', 'equipo', 'minuto', 'es_autogol', 'es_penalti']
        widgets = {
            'minuto': forms.NumberInput(attrs={'min': 1, 'max': 120}),
        }


class TarjetaForm(forms.ModelForm):
    class Meta:
        model = Tarjeta
        fields = ['jugador', 'equipo', 'tipo', 'minuto']
        widgets = {
            'minuto': forms.NumberInput(attrs={'min': 1, 'max': 120}),
        }


class AlineacionForm(forms.ModelForm):
    class Meta:
        model = Alineacion
        fields = ['jugador', 'equipo', 'es_titular', 'posicion']


class CandidatoMVPForm(forms.ModelForm):
    class Meta:
        model = CandidatoMVP
        fields = ['jugador', 'grado']


class VotarMVPForm(forms.Form):
    identificacion = forms.CharField(
        max_length=20,
        label='Tu número de identificación',
        widget=forms.TextInput(attrs={'placeholder': 'Ej: 1234567890'})
    )
    candidato_id = forms.IntegerField(widget=forms.HiddenInput())


class SorteoForm(forms.Form):
    grados = forms.ModelMultipleChoiceField(
        queryset=Grado.objects.all(),
        widget=forms.CheckboxSelectMultiple(),
        label='Grados participantes'
    )
    paises = forms.ModelMultipleChoiceField(
        queryset=Pais.objects.all(),
        widget=forms.CheckboxSelectMultiple(),
        label='Países disponibles'
    )

    def __init__(self, torneo=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if torneo:
            self.fields['grados'].queryset = Grado.objects.filter(ciclo=torneo.ciclo)
