import random
from itertools import combinations
from .models import (
    Torneo, Equipo, Grupo, EquipoGrupo, Partido,
    Gol, Tarjeta, Pais, Grado, JugadorEquipo
)


class SorteoService:
    """Asigna países aleatoriamente a grados de un torneo (tipo sorteo Mundial)"""

    @staticmethod
    def realizar_sorteo(torneo, grados_ids, paises_ids):
        if Equipo.objects.filter(torneo=torneo).exists():
            raise ValueError("Este torneo ya tiene equipos asignados.")

        grados = list(Grado.objects.filter(id__in=grados_ids))
        paises = list(Pais.objects.filter(id__in=paises_ids))

        if len(paises) < len(grados):
            raise ValueError(f"Se necesitan al menos {len(grados)} países. Solo hay {len(paises)}.")

        paises_sorteados = random.sample(paises, len(grados))
        random.shuffle(grados)

        equipos_creados = []
        for grado, pais in zip(grados, paises_sorteados):
            equipo, _ = Equipo.objects.get_or_create(
                torneo=torneo,
                grado=grado,
                defaults={'pais': pais}
            )
            equipos_creados.append(equipo)

        torneo.estado = 'sorteo'
        torneo.save()
        return equipos_creados

    @staticmethod
    def realizar_sorteo_ruleta(torneo, pares):
        """
        Recibe lista de strings "grado_id:pais_id" desde la ruleta JS
        y crea los equipos con esa asignación exacta.
        """
        if Equipo.objects.filter(torneo=torneo).exists():
            raise ValueError("Este torneo ya tiene equipos asignados.")
        if not pares:
            raise ValueError("No se recibieron pares de asignación.")

        equipos_creados = []
        for par in pares:
            try:
                grado_id, pais_id = par.split(':')
                grado = Grado.objects.get(id=grado_id)
                pais = Pais.objects.get(id=pais_id)
                equipo = Equipo.objects.create(torneo=torneo, grado=grado, pais=pais)
                equipos_creados.append(equipo)
            except (ValueError, Grado.DoesNotExist, Pais.DoesNotExist) as e:
                raise ValueError(f"Error en par '{par}': {e}")

        torneo.estado = 'sorteo'
        torneo.save()
        return equipos_creados

    @staticmethod
        """Elimina equipos y partidos para rehacer sorteo"""
        torneo.partidos.all().delete()
        torneo.grupos.all().delete()
        torneo.equipos.all().delete()
        torneo.estado = 'pendiente'
        torneo.save()


class GruposService:
    """Genera grupos estilo Mundial"""

    @staticmethod
    def generar_grupos(torneo, equipos_por_grupo=4):
        equipos = list(torneo.equipos.all())
        if not equipos:
            raise ValueError("No hay equipos para organizar en grupos.")

        random.shuffle(equipos)
        letras = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
        num_grupos = max(1, len(equipos) // equipos_por_grupo)

        Grupo.objects.filter(torneo=torneo).delete()
        grupos_creados = []

        for i in range(num_grupos):
            grupo = Grupo.objects.create(torneo=torneo, nombre=letras[i])
            inicio = i * equipos_por_grupo
            fin = inicio + equipos_por_grupo
            for equipo in equipos[inicio:fin]:
                EquipoGrupo.objects.create(grupo=grupo, equipo=equipo)
            grupos_creados.append(grupo)

        # Equipos sobrantes al último grupo
        sobrantes = equipos[num_grupos * equipos_por_grupo:]
        if sobrantes and grupos_creados:
            for eq in sobrantes:
                EquipoGrupo.objects.create(grupo=grupos_creados[-1], equipo=eq)

        return grupos_creados


class FixtureService:
    """Genera fixtures sin repetir partidos"""

    @staticmethod
    def generar_fixture_grupos(torneo):
        """Un partido por cada par de equipos dentro del grupo"""
        Partido.objects.filter(torneo=torneo, fase='grupos').delete()
        numero_partido = 1
        partidos_creados = []

        for grupo in torneo.grupos.all().prefetch_related('equipos__equipo'):
            equipos = [eg.equipo for eg in grupo.equipos.all()]
            for local, visitante in combinations(equipos, 2):
                partido = Partido.objects.create(
                    torneo=torneo,
                    grupo=grupo,
                    equipo_local=local,
                    equipo_visitante=visitante,
                    numero_partido=numero_partido,
                    fase='grupos',
                    estado='programado'
                )
                partidos_creados.append(partido)
                numero_partido += 1

        torneo.estado = 'en_curso'
        torneo.save()
        return partidos_creados

    @staticmethod
    def generar_fixture_todos_contra_todos(torneo):
        """Todos contra todos sin grupos"""
        Partido.objects.filter(torneo=torneo).delete()
        Grupo.objects.filter(torneo=torneo).delete()

        equipos = list(torneo.equipos.all())
        numero_partido = 1
        partidos_creados = []

        for local, visitante in combinations(equipos, 2):
            partido = Partido.objects.create(
                torneo=torneo,
                equipo_local=local,
                equipo_visitante=visitante,
                numero_partido=numero_partido,
                fase='grupos',
                estado='programado'
            )
            partidos_creados.append(partido)
            numero_partido += 1

        torneo.estado = 'en_curso'
        torneo.save()
        return partidos_creados


class EstadisticasService:
    """Actualiza tabla de posiciones al registrar resultado"""

    @staticmethod
    def recalcular_tabla_grupo(grupo):
        """Recalcula toda la tabla del grupo desde cero"""
        equipos_grupo = EquipoGrupo.objects.filter(grupo=grupo)
        for eg in equipos_grupo:
            eg.puntos = 0
            eg.partidos_jugados = 0
            eg.partidos_ganados = 0
            eg.partidos_empatados = 0
            eg.partidos_perdidos = 0
            eg.goles_favor = 0
            eg.goles_contra = 0
            eg.valla_invicta = True
            eg.save()

        partidos = Partido.objects.filter(grupo=grupo, estado='finalizado')
        for partido in partidos:
            EstadisticasService._aplicar_resultado(partido)

    @staticmethod
    def _aplicar_resultado(partido):
        if partido.grupo:
            for equipo, gf, gc in [
                (partido.equipo_local, partido.goles_local, partido.goles_visitante),
                (partido.equipo_visitante, partido.goles_visitante, partido.goles_local)
            ]:
                try:
                    eg = EquipoGrupo.objects.get(grupo=partido.grupo, equipo=equipo)
                    eg.partidos_jugados += 1
                    eg.goles_favor += gf
                    eg.goles_contra += gc
                    if gc > 0:
                        eg.valla_invicta = False
                    if gf > gc:
                        eg.puntos += 3
                        eg.partidos_ganados += 1
                    elif gf == gc:
                        eg.puntos += 1
                        eg.partidos_empatados += 1
                    else:
                        eg.partidos_perdidos += 1
                    eg.save()
                except EquipoGrupo.DoesNotExist:
                    pass

    @staticmethod
    def top_goleadores(torneo, limite=10):
        from django.db.models import Count
        from .models import Gol, Jugador
        return (
            Gol.objects
            .filter(partido__torneo=torneo, es_autogol=False)
            .values('jugador__id', 'jugador__nombre', 'jugador__apellido', 'equipo__pais__nombre')
            .annotate(total=Count('id'))
            .order_by('-total')[:limite]
        )

    @staticmethod
    def equipos_valla_invicta(torneo):
        return EquipoGrupo.objects.filter(
            grupo__torneo=torneo,
            valla_invicta=True,
            partidos_jugados__gt=0
        ).select_related('equipo__pais', 'equipo__grado')
