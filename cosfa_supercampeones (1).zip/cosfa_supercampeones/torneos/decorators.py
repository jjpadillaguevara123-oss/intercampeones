from functools import wraps
from django.shortcuts import redirect


def admin_cosfa_required(view_func):
    """Decorador que verifica si el usuario es admin del sistema Cosfa"""
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.session.get('es_admin_cosfa'):
            return redirect('login_admin')
        return view_func(request, *args, **kwargs)
    return wrapper
