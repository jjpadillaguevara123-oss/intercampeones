from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.conf import settings
from django.db.models import Count
from .models import (
    AnoLectivo, Torneo, Equipo, Partido, Grupo, EquipoGrupo,
    Jugador, Grado, Ciclo, Pais, CandidatoMVP, Gol, Tarjeta, Alineacion
)
from .forms import (
    AnoLectivoForm, TorneoForm, GradoForm, JugadorForm, PaisForm,
    EquipoForm, RegistrarResultadoForm, GolForm, TarjetaForm,
    AlineacionForm, CandidatoMVPForm, SorteoForm
)
from .services import SorteoService, GruposService, FixtureService, EstadisticasService
from .decorators import admin_cosfa_required


# ─── AUTH ───────────────────────────────────────────────────────────────

def login_admin(request):
    error = None
    if request.method == 'POST':
        password = request.POST.get('password', '')
        if password == settings.ADMIN_PASSWORD:
            request.session['es_admin_cosfa'] = True
            return redirect('admin_dashboard')
        else:
            error = "Contraseña incorrecta. Inténtalo de nuevo."
    return render(request, 'admin_cosfa/login.html', {'error': error})


def logout_admin(request):
    request.session.flush()
    return redirect('inicio')


# ─── DASHBOARD ──────────────────────────────────────────────────────────

@admin_cosfa_required
def dashboard(request):
    ano_activo = AnoLectivo.objects.filter(activo=True).first()
    context = {
        'ano_activo': ano_activo,
        'total_torneos': Torneo.objects.filter(ano_lectivo=ano_activo).count() if ano_activo else 0,
        'total_jugadores': Jugador.objects.filter(activo=True).count(),
        'total_partidos': Partido.objects.filter(torneo__ano_lectivo=ano_activo).count() if ano_activo else 0,
        'partidos_pendientes': Partido.objects.filter(torneo__ano_lectivo=ano_activo, estado='programado').count() if ano_activo else 0,
        'torneos': Torneo.objects.filter(ano_lectivo=ano_activo).select_related('ciclo') if ano_activo else [],
        'anos': AnoLectivo.objects.all(),
    }
    return render(request, 'admin_cosfa/dashboard.html', context)


# ─── AÑOS LECTIVOS ──────────────────────────────────────────────────────

@admin_cosfa_required
def gestionar_anos(request):
    anos = AnoLectivo.objects.all()
    form = AnoLectivoForm()
    if request.method == 'POST':
        form = AnoLectivoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Año lectivo creado correctamente.")
            return redirect('admin_anos')
    return render(request, 'admin_cosfa/anos.html', {'anos': anos, 'form': form})


@admin_cosfa_required
def editar_ano(request, ano_id):
    ano = get_object_or_404(AnoLectivo, id=ano_id)
    form = AnoLectivoForm(request.POST or None, instance=ano)
    if form.is_valid():
        form.save()
        messages.success(request, "Año lectivo actualizado.")
        return redirect('admin_anos')
    return render(request, 'admin_cosfa/form_generico.html', {'form': form, 'titulo': 'Editar Año Lectivo'})


# ─── TORNEOS ────────────────────────────────────────────────────────────

@admin_cosfa_required
def gestionar_torneos(request):
    ano_activo = AnoLectivo.objects.filter(activo=True).first()
    torneos = Torneo.objects.filter(ano_lectivo=ano_activo).select_related('ciclo') if ano_activo else []
    form = TorneoForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, "Torneo creado.")
        return redirect('admin_torneos')
    return render(request, 'admin_cosfa/torneos.html', {
        'torneos': torneos, 'form': form, 'ano_activo': ano_activo
    })


@admin_cosfa_required
def eliminar_torneo(request, torneo_id):
    torneo = get_object_or_404(Torneo, id=torneo_id)
    if request.method == 'POST':
        torneo.delete()
        messages.success(request, "Torneo eliminado.")
    return redirect('admin_torneos')


# ─── SORTEO ─────────────────────────────────────────────────────────────

@admin_cosfa_required
def realizar_sorteo(request, torneo_id):
    torneo = get_object_or_404(Torneo, id=torneo_id)
    grados_ciclo = Grado.objects.filter(ciclo=torneo.ciclo)
    paises = Pais.objects.all()
    equipos_existentes = torneo.equipos.select_related('pais', 'grado').all()

    if request.method == 'POST':
        accion = request.POST.get('accion')

        if accion == 'rehacer':
            SorteoService.rehacer_sorteo(torneo)
            messages.success(request, "Sorteo reiniciado.")
            return redirect('admin_sorteo', torneo_id=torneo_id)

        elif accion == 'sortear':
            grados_ids = request.POST.getlist('grados')
            paises_ids = request.POST.getlist('paises')
            try:
                SorteoService.realizar_sorteo(torneo, grados_ids, paises_ids)
                messages.success(request, "¡Sorteo realizado con éxito! Los países han sido asignados aleatoriamente.")
            except ValueError as e:
                messages.error(request, str(e))
            return redirect('admin_sorteo', torneo_id=torneo_id)

        elif accion == 'sortear_ruleta':
            # Formato: pares grado_id:pais_id enviados desde la ruleta JS
            pares = request.POST.getlist('par')  # ["grado_id:pais_id", ...]
            try:
                if not pares:
                    raise ValueError("No se recibieron asignaciones de la ruleta.")
                SorteoService.realizar_sorteo_ruleta(torneo, pares)
                messages.success(request, f"¡Sorteo de ruleta guardado! {len(pares)} equipos creados.")
            except ValueError as e:
                messages.error(request, str(e))
            return redirect('admin_sorteo', torneo_id=torneo_id)

        elif accion == 'generar_grupos':
            epp = int(request.POST.get('equipos_por_grupo', 4))
            try:
                GruposService.generar_grupos(torneo, epp)
                messages.success(request, "Grupos generados.")
            except ValueError as e:
                messages.error(request, str(e))
            return redirect('admin_sorteo', torneo_id=torneo_id)

        elif accion == 'generar_fixture':
            try:
                if torneo.formato == 'grupos':
                    FixtureService.generar_fixture_grupos(torneo)
                else:
                    FixtureService.generar_fixture_todos_contra_todos(torneo)
                messages.success(request, f"Fixture generado con {torneo.total_partidos()} partidos.")
            except Exception as e:
                messages.error(request, str(e))
            return redirect('admin_sorteo', torneo_id=torneo_id)

    grupos = torneo.grupos.prefetch_related('equipos__equipo__pais', 'equipos__equipo__grado').all()
    partidos = torneo.partidos.select_related('equipo_local__pais', 'equipo_visitante__pais').all()

    context = {
        'torneo': torneo,
        'grados_ciclo': grados_ciclo,
        'paises': paises,
        'equipos_existentes': equipos_existentes,
        'grupos': grupos,
        'partidos': partidos,
    }
    return render(request, 'admin_cosfa/sorteo.html', context)


# ─── PARTIDOS ───────────────────────────────────────────────────────────

@admin_cosfa_required
def lista_partidos(request, torneo_id):
    torneo = get_object_or_404(Torneo, id=torneo_id)
    partidos = torneo.partidos.select_related(
        'equipo_local__pais', 'equipo_local__grado',
        'equipo_visitante__pais', 'equipo_visitante__grado',
        'grupo'
    ).all()
    return render(request, 'admin_cosfa/lista_partidos.html', {
        'torneo': torneo, 'partidos': partidos
    })


@admin_cosfa_required
def registrar_partido(request, partido_id):
    partido = get_object_or_404(Partido, id=partido_id)
    torneo = partido.torneo

    goles = partido.goles.select_related('jugador', 'equipo__pais').all()
    tarjetas = partido.tarjetas.select_related('jugador', 'equipo__pais').all()
    alineaciones = partido.alineaciones.select_related('jugador', 'equipo__pais').all()

    # Jugadores de ambos equipos
    jugadores_local = partido.equipo_local.jugadores.select_related('jugador').all()
    jugadores_visitante = partido.equipo_visitante.jugadores.select_related('jugador').all()

    if request.method == 'POST':
        accion = request.POST.get('accion')

        if accion == 'resultado':
            form = RegistrarResultadoForm(request.POST, instance=partido)
            if form.is_valid():
                partido_guardado = form.save(commit=False)
                partido_guardado.estado = 'finalizado'
                partido_guardado.save()
                if partido.grupo:
                    EstadisticasService.recalcular_tabla_grupo(partido.grupo)
                messages.success(request, "Resultado registrado y tabla actualizada.")

        elif accion == 'gol':
            jugador_id = request.POST.get('jugador')
            equipo_id = request.POST.get('equipo')
            minuto = request.POST.get('minuto') or None
            es_autogol = request.POST.get('es_autogol') == 'on'
            es_penalti = request.POST.get('es_penalti') == 'on'
            Gol.objects.create(
                partido=partido,
                jugador_id=jugador_id,
                equipo_id=equipo_id,
                minuto=minuto,
                es_autogol=es_autogol,
                es_penalti=es_penalti
            )
            messages.success(request, "Gol registrado.")

        elif accion == 'tarjeta':
            jugador_id = request.POST.get('jugador')
            equipo_id = request.POST.get('equipo')
            tipo = request.POST.get('tipo')
            minuto = request.POST.get('minuto') or None
            Tarjeta.objects.create(
                partido=partido,
                jugador_id=jugador_id,
                equipo_id=equipo_id,
                tipo=tipo,
                minuto=minuto
            )
            messages.success(request, "Tarjeta registrada.")

        elif accion == 'alineacion':
            jugador_id = request.POST.get('jugador')
            equipo_id = request.POST.get('equipo')
            es_titular = request.POST.get('es_titular') == 'on'
            posicion = request.POST.get('posicion', '')
            Alineacion.objects.get_or_create(
                partido=partido,
                jugador_id=jugador_id,
                defaults={'equipo_id': equipo_id, 'es_titular': es_titular, 'posicion': posicion}
            )
            messages.success(request, "Alineación registrada.")

        elif accion == 'eliminar_gol':
            Gol.objects.filter(id=request.POST.get('gol_id'), partido=partido).delete()
            if partido.grupo:
                EstadisticasService.recalcular_tabla_grupo(partido.grupo)
            messages.success(request, "Gol eliminado.")

        elif accion == 'eliminar_tarjeta':
            Tarjeta.objects.filter(id=request.POST.get('tarjeta_id'), partido=partido).delete()
            messages.success(request, "Tarjeta eliminada.")

        return redirect('admin_registrar_partido', partido_id=partido_id)

    form_resultado = RegistrarResultadoForm(instance=partido)
    context = {
        'partido': partido,
        'torneo': torneo,
        'form_resultado': form_resultado,
        'goles': goles,
        'tarjetas': tarjetas,
        'alineaciones': alineaciones,
        'jugadores_local': jugadores_local,
        'jugadores_visitante': jugadores_visitante,
    }
    return render(request, 'admin_cosfa/registrar_partido.html', context)


# ─── JUGADORES ──────────────────────────────────────────────────────────

@admin_cosfa_required
def gestionar_jugadores(request):
    jugadores = Jugador.objects.select_related('grado__ciclo').all()
    grados = Grado.objects.select_related('ciclo').all()
    form = JugadorForm(request.POST or None, request.FILES or None)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, "Jugador registrado.")
        return redirect('admin_jugadores')
    return render(request, 'admin_cosfa/jugadores.html', {
        'jugadores': jugadores, 'form': form, 'grados': grados
    })


@admin_cosfa_required
def editar_jugador(request, jugador_id):
    jugador = get_object_or_404(Jugador, id=jugador_id)
    form = JugadorForm(request.POST or None, request.FILES or None, instance=jugador)
    if form.is_valid():
        form.save()
        messages.success(request, "Jugador actualizado.")
        return redirect('admin_jugadores')
    return render(request, 'admin_cosfa/form_generico.html', {
        'form': form, 'titulo': f'Editar Jugador: {jugador.nombre_completo}'
    })


@admin_cosfa_required
def eliminar_jugador(request, jugador_id):
    jugador = get_object_or_404(Jugador, id=jugador_id)
    if request.method == 'POST':
        jugador.activo = False
        jugador.save()
        messages.success(request, "Jugador desactivado.")
    return redirect('admin_jugadores')


# ─── GRADOS ─────────────────────────────────────────────────────────────

@admin_cosfa_required
def gestionar_grados(request):
    grados = Grado.objects.select_related('ciclo').all()
    form = GradoForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, "Grado creado.")
        return redirect('admin_grados')
    return render(request, 'admin_cosfa/grados.html', {'grados': grados, 'form': form})


# ─── PAÍSES ─────────────────────────────────────────────────────────────

@admin_cosfa_required
def gestionar_paises(request):
    paises = Pais.objects.all()
    form = PaisForm(request.POST or None, request.FILES or None)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, "País agregado.")
        return redirect('admin_paises')
    return render(request, 'admin_cosfa/paises.html', {'paises': paises, 'form': form})


@admin_cosfa_required
def editar_pais(request, pais_id):
    pais = get_object_or_404(Pais, id=pais_id)
    form = PaisForm(request.POST or None, request.FILES or None, instance=pais)
    if form.is_valid():
        form.save()
        messages.success(request, "País actualizado.")
        return redirect('admin_paises')
    return render(request, 'admin_cosfa/form_generico.html', {
        'form': form, 'titulo': f'Editar País: {pais.nombre}'
    })


# ─── EQUIPOS ─────────────────────────────────────────────────────────────

@admin_cosfa_required
def gestionar_equipo(request, equipo_id):
    equipo = get_object_or_404(Equipo, id=equipo_id)
    jugadores_grado = Jugador.objects.filter(grado=equipo.grado, activo=True)
    jugadores_equipo = equipo.jugadores.select_related('jugador').all()

    if request.method == 'POST':
        accion = request.POST.get('accion')

        if accion == 'agregar_jugador':
            jugador_id = request.POST.get('jugador_id')
            es_capitan = request.POST.get('es_capitan') == 'on'
            numero = request.POST.get('numero_camiseta') or None
            je, created = JugadorEquipo.objects.get_or_create(
                jugador_id=jugador_id,
                equipo=equipo,
                defaults={'es_capitan': es_capitan, 'numero_camiseta': numero}
            )
            if es_capitan:
                equipo.capitan_id = jugador_id
                equipo.save()
            messages.success(request, "Jugador agregado al equipo." if created else "Jugador ya estaba en el equipo.")

        elif accion == 'quitar_jugador':
            JugadorEquipo.objects.filter(id=request.POST.get('je_id')).delete()
            messages.success(request, "Jugador removido.")

        elif accion == 'subir_logo':
            if request.FILES.get('logo'):
                equipo.logo = request.FILES['logo']
                equipo.save()
                messages.success(request, "Logo actualizado.")

        return redirect('admin_equipo', equipo_id=equipo_id)

    from .models import JugadorEquipo
    context = {
        'equipo': equipo,
        'jugadores_grado': jugadores_grado,
        'jugadores_equipo': jugadores_equipo,
    }
    return render(request, 'admin_cosfa/equipo_detalle.html', context)


# ─── MVP ─────────────────────────────────────────────────────────────────

@admin_cosfa_required
def gestionar_mvp(request, torneo_id):
    torneo = get_object_or_404(Torneo, id=torneo_id)

    if not torneo.puede_tener_mvp():
        messages.error(request, "El MVP solo aplica para Ciclos III y IV.")
        return redirect('admin_dashboard')

    candidatos = torneo.candidatos_mvp.select_related('jugador', 'grado').annotate(
        total_votos=Count('votos_recibidos')
    ).order_by('-total_votos')

    if request.method == 'POST':
        accion = request.POST.get('accion')

        if accion == 'toggle_mvp':
            torneo.mvp_activo = not torneo.mvp_activo
            torneo.save()
            estado = "activada" if torneo.mvp_activo else "desactivada"
            messages.success(request, f"Votación MVP {estado}.")

        elif accion == 'agregar_candidato':
            jugador_id = request.POST.get('jugador_id')
            grado_id = request.POST.get('grado_id')
            CandidatoMVP.objects.get_or_create(
                torneo=torneo,
                jugador_id=jugador_id,
                defaults={'grado_id': grado_id}
            )
            messages.success(request, "Candidato agregado.")

        elif accion == 'eliminar_candidato':
            CandidatoMVP.objects.filter(id=request.POST.get('candidato_id')).delete()
            messages.success(request, "Candidato eliminado.")

        return redirect('admin_mvp', torneo_id=torneo_id)

    jugadores = Jugador.objects.filter(grado__ciclo=torneo.ciclo, activo=True).select_related('grado')
    context = {
        'torneo': torneo,
        'candidatos': candidatos,
        'jugadores': jugadores,
    }
    return render(request, 'admin_cosfa/mvp.html', context)
