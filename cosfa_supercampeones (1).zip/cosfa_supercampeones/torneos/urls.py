from django.urls import path
from . import views, views_admin

urlpatterns = [
    # ── PÚBLICAS ────────────────────────────────────────────
    path('', views.inicio, name='inicio'),
    path('torneo/<int:torneo_id>/', views.detalle_torneo, name='detalle_torneo'),
    path('torneo/<int:torneo_id>/tabla/', views.tabla_posiciones, name='tabla_posiciones'),
    path('torneo/<int:torneo_id>/calendario/', views.calendario, name='calendario'),
    path('torneo/<int:torneo_id>/estadisticas/', views.estadisticas, name='estadisticas'),
    path('torneo/<int:torneo_id>/mvp/', views.mvp_view, name='mvp'),
    path('torneo/<int:torneo_id>/mvp/votar/<int:candidato_id>/', views.votar_mvp, name='votar_mvp'),
    path('partido/<int:partido_id>/', views.detalle_partido, name='detalle_partido'),

    # ── AUTH ADMIN ──────────────────────────────────────────
    path('admin-cosfa/login/', views_admin.login_admin, name='login_admin'),
    path('admin-cosfa/logout/', views_admin.logout_admin, name='logout_admin'),

    # ── PANEL ADMIN ─────────────────────────────────────────
    path('admin-cosfa/', views_admin.dashboard, name='admin_dashboard'),

    # Años lectivos
    path('admin-cosfa/anos/', views_admin.gestionar_anos, name='admin_anos'),
    path('admin-cosfa/anos/<int:ano_id>/editar/', views_admin.editar_ano, name='admin_editar_ano'),

    # Torneos
    path('admin-cosfa/torneos/', views_admin.gestionar_torneos, name='admin_torneos'),
    path('admin-cosfa/torneos/<int:torneo_id>/eliminar/', views_admin.eliminar_torneo, name='admin_eliminar_torneo'),

    # Sorteo y fixture
    path('admin-cosfa/sorteo/<int:torneo_id>/', views_admin.realizar_sorteo, name='admin_sorteo'),

    # Partidos
    path('admin-cosfa/torneos/<int:torneo_id>/partidos/', views_admin.lista_partidos, name='admin_partidos'),
    path('admin-cosfa/partido/<int:partido_id>/registrar/', views_admin.registrar_partido, name='admin_registrar_partido'),

    # Jugadores
    path('admin-cosfa/jugadores/', views_admin.gestionar_jugadores, name='admin_jugadores'),
    path('admin-cosfa/jugadores/<int:jugador_id>/editar/', views_admin.editar_jugador, name='admin_editar_jugador'),
    path('admin-cosfa/jugadores/<int:jugador_id>/eliminar/', views_admin.eliminar_jugador, name='admin_eliminar_jugador'),

    # Grados
    path('admin-cosfa/grados/', views_admin.gestionar_grados, name='admin_grados'),

    # Países
    path('admin-cosfa/paises/', views_admin.gestionar_paises, name='admin_paises'),
    path('admin-cosfa/paises/<int:pais_id>/editar/', views_admin.editar_pais, name='admin_editar_pais'),

    # Equipos
    path('admin-cosfa/equipo/<int:equipo_id>/', views_admin.gestionar_equipo, name='admin_equipo'),

    # MVP
    path('admin-cosfa/mvp/<int:torneo_id>/', views_admin.gestionar_mvp, name='admin_mvp'),
]
