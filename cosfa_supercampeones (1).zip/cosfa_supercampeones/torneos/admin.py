from django.contrib import admin
from .models import (
    AnoLectivo, Pais, Ciclo, Grado, Jugador, Torneo,
    Equipo, JugadorEquipo, Grupo, EquipoGrupo, Partido,
    Gol, Tarjeta, Alineacion, CandidatoMVP, VotoMVP
)

admin.site.site_header = "Cosfa Supercampeones - Admin Django"

admin.site.register(AnoLectivo)
admin.site.register(Pais)
admin.site.register(Ciclo)
admin.site.register(Grado)
admin.site.register(Jugador)
admin.site.register(Torneo)
admin.site.register(Equipo)
admin.site.register(JugadorEquipo)
admin.site.register(Grupo)
admin.site.register(EquipoGrupo)
admin.site.register(Partido)
admin.site.register(Gol)
admin.site.register(Tarjeta)
admin.site.register(Alineacion)
admin.site.register(CandidatoMVP)
admin.site.register(VotoMVP)
