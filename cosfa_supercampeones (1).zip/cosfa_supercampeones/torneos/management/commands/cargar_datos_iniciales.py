from django.core.management.base import BaseCommand
from torneos.models import Pais, Ciclo, Grado


class Command(BaseCommand):
    help = 'Carga datos iniciales: países, ciclos y grados'

    def handle(self, *args, **kwargs):
        self.cargar_paises()
        self.cargar_ciclos_y_grados()
        self.stdout.write(self.style.SUCCESS('✅ Datos iniciales cargados correctamente.'))

    def cargar_paises(self):
        paises = [
            ('Brasil', 'BRA', '#009C3B', '#FFDF00'),
            ('Argentina', 'ARG', '#74ACDF', '#FFFFFF'),
            ('Francia', 'FRA', '#002395', '#ED2939'),
            ('Alemania', 'GER', '#000000', '#DD0000'),
            ('España', 'ESP', '#AA151B', '#F1BF00'),
            ('Portugal', 'POR', '#006600', '#FF0000'),
            ('Inglaterra', 'ENG', '#FFFFFF', '#CF081F'),
            ('Italia', 'ITA', '#009246', '#CF2734'),
            ('Colombia', 'COL', '#FCD116', '#003087'),
            ('México', 'MEX', '#006847', '#CE1126'),
            ('Uruguay', 'URU', '#5EB6E4', '#FFFFFF'),
            ('Croacia', 'CRO', '#FF0000', '#FFFFFF'),
            ('Marruecos', 'MAR', '#C1272D', '#006233'),
            ('Japón', 'JPN', '#BC002D', '#FFFFFF'),
            ('Senegal', 'SEN', '#00853F', '#FDEF42'),
            ('Estados Unidos', 'USA', '#B31942', '#0A3161'),
            ('Australia', 'AUS', '#00008B', '#FF0000'),
            ('Corea del Sur', 'KOR', '#003478', '#CD2E3A'),
            ('Ghana', 'GHA', '#006B3F', '#FCD116'),
            ('Ecuador', 'ECU', '#FFD100', '#003DA5'),
            ('Países Bajos', 'NED', '#FF6600', '#FFFFFF'),
            ('Bélgica', 'BEL', '#000000', '#F50001'),
            ('Suiza', 'SUI', '#FF0000', '#FFFFFF'),
            ('Polonia', 'POL', '#DC143C', '#FFFFFF'),
            ('Dinamarca', 'DEN', '#C60C30', '#FFFFFF'),
            ('Suecia', 'SWE', '#006AA7', '#FECC02'),
            ('Chile', 'CHI', '#D52B1E', '#FFFFFF'),
            ('Perú', 'PER', '#D91023', '#FFFFFF'),
            ('Venezuela', 'VEN', '#CF142B', '#003893'),
            ('Paraguay', 'PAR', '#D52B1E', '#FFFFFF'),
            ('Bolivia', 'BOL', '#D52B1E', '#F4E400'),
            ('Costa Rica', 'CRC', '#002B7F', '#CE1126'),
        ]

        creados = 0
        for nombre, codigo, color1, color2 in paises:
            _, created = Pais.objects.get_or_create(
                codigo=codigo,
                defaults={
                    'nombre': nombre,
                    'color_principal': color1,
                    'color_secundario': color2,
                }
            )
            if created:
                creados += 1

        self.stdout.write(f'  🌍 Países: {creados} nuevos creados.')

    def cargar_ciclos_y_grados(self):
        ciclos_data = [
            ('I', 'Ciclo I - Básica Primaria', [
                ('1°', 1), ('2°', 2),
            ]),
            ('II', 'Ciclo II - Básica Primaria', [
                ('3°', 1), ('4°', 2), ('5°', 3),
            ]),
            ('III', 'Ciclo III - Básica Secundaria', [
                ('6°', 1), ('7°', 2), ('8°', 3),
            ]),
            ('IV', 'Ciclo IV - Media y Profesores', [
                ('9°', 1), ('10°', 2), ('11°', 3), ('Profesores', 4),
            ]),
        ]

        for ciclo_nombre, descripcion, grados in ciclos_data:
            ciclo, _ = Ciclo.objects.get_or_create(
                nombre=ciclo_nombre,
                defaults={'descripcion': descripcion}
            )
            for grado_nombre, orden in grados:
                Grado.objects.get_or_create(
                    nombre=grado_nombre,
                    ciclo=ciclo,
                    defaults={'orden': orden}
                )

        self.stdout.write('  🏫 Ciclos y grados cargados.')
